<?php
// ShortCodes For plugins
global $cwebPluginName;
global $PluginTextDomain;
global $wpdb;