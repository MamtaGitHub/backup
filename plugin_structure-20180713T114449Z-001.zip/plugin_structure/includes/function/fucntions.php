<?php 
/** @wordpress-plugin
 * Author:            cWebco WP Plugin Team
 * Author URI:        http://www.cwebconsultants.com/
 */
/* Function for session message */
if (!function_exists('set_error_message')) {
    function set_error_message($msg,$type){
        @session_start();
        if(isset($_SESSION['error_msg'])):  
            unset($_SESSION['error_msg']);
        endif;

        $_SESSION['error_msg']['msg']=$msg;
        $_SESSION['error_msg']['error']=$type;
        return true;
    }
}

if (!function_exists('show_error_message')) {
    function show_error_message(){
        $msg='';
        @session_start();

        if(isset($_SESSION['error_msg']) && isset($_SESSION['error_msg']['msg'])): 
            if($_SESSION['error_msg']['error']=='1'):
                    $tp='message_error';
            else:
                    $tp='message_success';
            endif;	
            $msg.='<div class="portlet light pro_mess"><div class="message center pmpro_message '.$tp.'">';
                    $msg.=$_SESSION['error_msg']['msg']; 
            $msg.='</div></div>'; 
            unset($_SESSION['error_msg']['msg']);
            unset($_SESSION['error_msg']['error']);
            unset($_SESSION['error_msg']);
        endif;	

        return $msg;
    }
}	

if (!function_exists('pr')) {
    function pr($post){
        echo '<pre>';
            print_r($post);
        echo '</pre>';
    }
}

if (!function_exists('do_account_redirect')) {
	//Finishing setting templates 
	function do_account_redirect($url) {
		global $post, $wp_query;

		if (have_posts()) {
			include($url);
			die();
		} else {
			$wp_query->is_404 = true;
		}
	}
}

add_action( 'init', 'theme_name_scripts' );

function theme_name_scripts() {
   
    if (!is_admin() && $GLOBALS['pagenow'] != 'wp-login.php') {
        $component_css_path = CWEB_WS_PATH1 . 'public/assets/css/components.css';
        wp_enqueue_style('components', $component_css_path);

    } 
}

/* Function for Redirect */
if (!function_exists('foreceRedirect')) {
    function foreceRedirect($filename)
    {
        if (!headers_sent())
                 header('Location: '.$filename);
        else {
            echo '<script type="text/javascript">';
            echo 'window.location.href="'.$filename.'";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url='.$filename.'" />';
            echo '</noscript>';
        }
    }	
}
/* Function for Redirect --ENDS */