<?php
/** @wordpress-plugin
 * Author:            CwebConsultants
 * Author URI:        http://www.cwebconsultants.com/
 */

class Plugin_Activator {
	/* Activate Class */
	public static function activate() {
            
		global $wpdb;		   

		
                /* Delivery man information Table */
                $sqlQuery="CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."deliveryman_account` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `user_id` int(11) DEFAULT NULL,
                  `first_name` varchar(255) DEFAULT NULL,
                  `last_name` varchar(255) DEFAULT NULL,
		  `email` varchar(255) DEFAULT NULL,
		  `phone` varchar(12) DEFAULT NULL,
		  `address` varchar(255) DEFAULT NULL,
                  `address2` varchar(255) DEFAULT NULL,
                  `photo` int(11) DEFAULT NULL,
		  `photo_id_proof` int(11) DEFAULT NULL,
		  `rbi` int(11) DEFAULT NULL,
                  `insurance` int(11) DEFAULT NULL,
                  `proof_declartn_company` int(11) DEFAULT NULL,
		   `address_proof` int(11) DEFAULT NULL,
		   `pickup_zip` varchar(8) DEFAULT NULL,
                   `pickup_city` varchar(255) DEFAULT NULL,
                   `pickup_lan_lat` longtext DEFAULT NULL,
		   `delivery_zip` varchar(8) DEFAULT NULL,
                   `delivery_city` varchar(255) DEFAULT NULL,
                   `delivery_lan_lat` longtext DEFAULT NULL,
		   `register_date` varchar(255) DEFAULT NULL,
                   `is_approval` int(11) DEFAULT 0,
                   `available_credit` double DEFAULT 0,
                   `total_credit` double DEFAULT 0,
                   `redeem_credit` double DEFAULT 0,
                   `approval_date` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                $wpdb->query($sqlQuery);

                
                /* Delivery man Package information Table */
                $sqlQuery1="CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."deliveryman_package` (
                    `id` int(5) NOT NULL AUTO_INCREMENT,
                    `order_id` int(11) DEFAULT NULL,
                    `deliveryman_id` int(11) DEFAULT NULL,
                    `onDate` varchar(255) DEFAULT NULL,
                    `apply_date` varchar(255) DEFAULT NULL,
                    `apply_time` varchar(255) DEFAULT NULL,
                    `status` int(5) DEFAULT 0,
                    `Delivery_distance` float DEFAULT 0,
                    `Delivery_unit_price` double DEFAULT 0,
                    `Delivery_total_price` double DEFAULT 0,
                    `customer_id` int(11) DEFAULT NULL,
                    `customer_viewed` int(5) DEFAULT NULL,
                    `vendor_id` int(11) DEFAULT NULL,
                    `pickup_status` int(5) DEFAULT NULL,
                    `pickup_status_updated_date` varchar(255) DEFAULT NULL,
                    `pickup_datetime` varchar(255) DEFAULT NULL,
                    `pickup_location` varchar(255) DEFAULT NULL,
                    `secret_code` varchar(15) DEFAULT NULL,
                    `is_delivered` tinyint(4) DEFAULT NULL,
                    `is_code_validt_aftr_dlvry` tinyint(4) DEFAULT NULL,
                    `delivery_datetime` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                $wpdb->query($sqlQuery1);

                /* Delivery man information Table */
                $sqlQuery2="CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."deliveryman_credit` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `package_id` int(11) DEFAULT NULL,
                  `deliveryman_id` int(11) DEFAULT NULL,
                  `order_id` int(11) DEFAULT NULL,
		  `credit_amount` double DEFAULT 0,
		  `entry_date` int(11) DEFAULT NULL,
		  `credit_status` int(11) DEFAULT NULL,
                  `redeem_date` int(11) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                $wpdb->query($sqlQuery2);
                
                /* Delivery man Reviews Table */
                $sqlQuery2="CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."deliveryman_reviews` (
                  `id` int(5) NOT NULL AUTO_INCREMENT,
                  `deliveryman_id` int(11) DEFAULT NULL,
                  `customer_id` int(11) DEFAULT NULL,
		  `package_id` int(11) DEFAULT NULL,
                  `rating` int(5) DEFAULT NULL,
                  `review-title` varchar(255) DEFAULT NULL,
                  `reviews` longtext DEFAULT NULL,
		  `date_time` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                $wpdb->query($sqlQuery2);
                
                /* Delivery man Reviews Table */
                $sqlQuery2="CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."deliveryman_credit_request` (
                  `id` int(5) NOT NULL AUTO_INCREMENT,
                  `deliveryman_id` int(11) DEFAULT NULL,
                  `credit_ids` varchar(255) DEFAULT NULL,
		  `amount_to_redeem` double DEFAULT 0,
                  `request_date` varchar(255) DEFAULT NULL,
                  `request_status` int(11) DEFAULT 0,
		  `redeem_date` varchar(255) DEFAULT NULL,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                $wpdb->query($sqlQuery2);

                $ven_not_exist = $reg_not_exist = 0;
                
                $_for_reg_page = get_option('_reg_form_page');
                $_vender_page = get_option('_vender_page');
                
                
                /* Adding Registration page*/
                if(!empty($_for_reg_page)){
                    if(FALSE === get_post_status( $_for_reg_page )){
                        $reg_not_exist = 1;
                    }
                }else{
                    $reg_not_exist = 1;
                }
                
                if($reg_not_exist == 1){
                    $page['post_type']    = 'page';
                    $page['post_content'] = '[delivery_form]';
                    $page['post_parent']  = 0;
                    $page['post_author']  = 1;
                    $page['post_status']  = 'publish';
                    $page['post_title']   = 'Registration Form';
//                    $page = apply_filters('yourplugin_add_new_page', $page, 'teams');
                    $pageid = wp_insert_post ($page);
                    add_option( '_reg_form_page', $pageid );
                }
                
                /* Adding Vendor Front-end page*/
                if(!empty($_vender_page)){
                    if(FALSE === get_post_status( $_vender_page )){
                        $ven_not_exist = 1;
                    }
                }else{
                    $ven_not_exist = 1;
                }
                
                if($ven_not_exist == 1){
                    $page['post_type']    = 'page';
                    $page['post_content'] = '[vendor_section]';
                    $page['post_parent']  = 0;
                    $page['post_author']  = 1;
                    $page['post_status']  = 'publish';
                    $page['post_title']   = 'Package Information';
//                    $page = apply_filters('yourplugin_add_new_page', $page, 'teams');
                    $vender_pageid = wp_insert_post ($page);
                    add_option( '_vender_page', $vender_pageid );
                }
                
        }
}