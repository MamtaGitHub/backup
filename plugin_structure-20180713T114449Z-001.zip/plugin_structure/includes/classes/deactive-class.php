<?php
/** @wordpress-plugin
 * Author:            CwebConsultants
 * Author URI:        http://www.cwebconsultants.com/
 */

class Plugin_Deactivator {
	/* De-activate Class */
	public static function deactivate() {
		/* Delete Table And Post type*/
		global $wpdb;	

	}
}