<?php
include_once('includes/config.php');
include_once('/elements/header.php');
$plot_record = get_plot_name();

?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<table class="table table-condensed table-bordered table-checked">
				<tbody>
					<tr class="danger">
					<td>Plot type</td>
					<td>Total Avilable</td>
					<td>No of plotes</td>
					</tr>
					<?php foreach ($plot_record as $value) { 
					$number_plot_record = get_number_plot_record($value['id']);
                    // pr($number_plot_record['no_of_plots']);
                    if($number_plot_record['no_of_plots'] == ''){
                    	$number_plot_record['no_of_plots'] = 0;
                    }
					?>	
					
					<tr>
					<td><?php echo $value['plot_type']; ?></td>
					<td><?php echo $value['total_avilable']; ?></td>
					<td><?php echo $number_plot_record['no_of_plots']; ?></td>
					</tr>
					
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>


<div class="container">
	<div class="row">
		<div class="col-md-12">
			<table class="table table-condensed table-bordered table-checked">
				<tbody>
					<tr class="danger">
					<td>Plot type</td>
					<td>Collected Money</td>
					
					</tr>
					<?php foreach ($plot_record as $value) { 
						$collected_money = get_collected_money($value['id']);
						//pr($collected_money['totalcollected_amout']);
						if($collected_money['totalcollected_amout'] == ''){
						 $collected_money['totalcollected_amout'] = 0;
						}

					?>	
					
					<tr>
					<td><?php echo $value['plot_type']; ?></td>
					
					<td><?php echo $collected_money['totalcollected_amout'];?></td>
					</tr>
					
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php
include_once('/elements/footer.php');