<?php
session_start();
require_once __DIR__ .'/includes/config.php';
require_once __Dir__ .'/elements/header.php';
$plots = get_plot_name();
$candidate = get_candidate_name();
//pr($plots);
if(isset($_POST['save'])) {
 //pr($_POST);
 $plot_id  = $_POST['plots_name'];
 $candidate_name  = $_POST['candidate'];
 
 $total_avilable= get_total_avialable_plot($plot_id);
 $booked_plot = get_booked_plot($plot_id);
 $plot_price = get_entered_plot_price($plot_id);
 $plot_price_final= $plot_price['plot_price'];
$booked = $booked_plot['no_of_plots'];
//pr($booked_plot);
$entered_plot = $_POST['plots'];

$total = $booked + $entered_plot;
//pr($total);
if($total <= $total_avilable['total_avilable'])
 {
 	$no_of_plot = $entered_plot;
 	$amt = $plot_price_final * $no_of_plot;

 }
 else
 {
 	$_SESSION['plot_error'] = "Sorry your entered number of plots is not avilable in our store"; 
 	header('location:index.php');
 	die;
 }
$query = "INSERT INTO registration_plot SET plot_id ='{$plot_id}', candidate_id='{$candidate_name}',no_of_plots='{$no_of_plot}',totalcollected_amout='{$amt}'";
global $conn;
mysqli_query($conn,$query);
$_SESSION['success'] = "Your Record Successfully inserted"; 
header('location:index.php');
die;
}

?>
<div class="row">
<?php
if(isset($_SESSION['plot_error'])){
	echo $s = $_SESSION['plot_error'];
}
if(isset($_SESSION['success'])){
	echo $s = $_SESSION['success'];
}
?>
<form method="post">
<table class="table table-condensed table-borderd table-checked">
<tbody>
<tr>
<td>Plot Name</td>
<td>
<select name="plots_name" required>
<option value="">Select plots</option>
<?php foreach ($plots as $value) { 
?>
<option value="<?php echo $value['id']; ?>"><?php echo $value['plot_type'];?></option>
<?php } ?>
</select>
</td>
</tr>

<tr>
<td>Candidate Name</td>
<td>

<select name="candidate" required>
<option value="">Select Candidate</option>
<?php foreach ($candidate as $value) { ?>
<option value="<?php echo $value['id']; ?>"><?php echo $value['customer_name'];?></option>
<?php } ?>
</select>

</td>
</tr>

<tr><td>No of plots</td><td><input type="number" name="plots" required></td></tr>


</tbody>

<tfoot>
	<td colspan="2"><input type="submit" name="save"></td>
</tfoot>

</table>
</form>

</div>


<?php
session_destroy();
require_once __Dir__ .'/elements/footer.php';