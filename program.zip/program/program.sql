-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2017 at 01:04 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `program`
--

-- --------------------------------------------------------

--
-- Table structure for table `mst_candidate`
--

CREATE TABLE IF NOT EXISTS `mst_candidate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mst_candidate`
--

INSERT INTO `mst_candidate` (`id`, `customer_name`) VALUES
(1, 'cust1'),
(2, 'cust2'),
(3, 'cust3');

-- --------------------------------------------------------

--
-- Table structure for table `mst_plot`
--

CREATE TABLE IF NOT EXISTS `mst_plot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plot_type` varchar(50) NOT NULL,
  `total_avilable` int(11) NOT NULL,
  `plot_price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mst_plot`
--

INSERT INTO `mst_plot` (`id`, `plot_type`, `total_avilable`, `plot_price`) VALUES
(1, 'building', 1, 2000),
(2, 'flat', 12, 3000),
(3, 'twoBHK', 12, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `registration_plot`
--

CREATE TABLE IF NOT EXISTS `registration_plot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plot_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `no_of_plots` int(11) NOT NULL,
  `totalcollected_amout` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `registration_plot`
--

INSERT INTO `registration_plot` (`id`, `plot_id`, `candidate_id`, `no_of_plots`, `totalcollected_amout`) VALUES
(4, 2, 1, 7, 21000),
(5, 2, 1, 5, 15000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
