<!DOCTYPE html>
<html>
	<head>
	<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	</head>
	<body>
	<div class="container">
	<div class="row">
	<div class="col-md-12">
	<ul class="nav">
		<li style="display:inline-block;"><a href="index.php">Home</a></li>
		<li style="display:inline-block;"><a href="report.php">Reports</a></li>
	</ul>


	</div>
	</div>
	</div>
	<div class="container">
	