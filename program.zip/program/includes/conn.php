<?php
$conn = mysqli_connect("localhost","root","","program");
//print_r($conn);