<?php
 function pr($arr){
 	echo '<pre>';
 	print_r($arr);
 	echo '</pre>';
 }

function get_plot_name(){
 	$query = "SELECT * FROM mst_plot";
 	return get_result_from_query($query);
}
function get_collected_money($id){
$query = "SELECT SUM(totalcollected_amout) as totalcollected_amout FROM registration_plot WHERE plot_id='{$id}'";
 	return get_result_from_query($query,true);
}

function get_candidate_name(){
 	$query = "SELECT * FROM mst_candidate";
 	return get_result_from_query($query);
}

function get_number_plot_record($id){
$query = "SELECT SUM(no_of_plots) as no_of_plots FROM registration_plot WHERE plot_id='{$id}'";
 	return get_result_from_query($query,true);
}
function get_entered_plot_price($plot_id){
	$query = "SELECT plot_price FROM mst_plot WHERE id='{$plot_id}'";
 	return get_result_from_query($query,true);
}

function get_total_avialable_plot($plot_id){
 	$query = "SELECT total_avilable FROM mst_plot WHERE id='{$plot_id}'";
 	return get_result_from_query($query,true);
}

function get_booked_plot($plot_id){
 	$query = "SELECT SUM(no_of_plots) as no_of_plots FROM registration_plot WHERE plot_id='{$plot_id}'";
 	return get_result_from_query($query,true);
}

function get_result_from_query($query, $first_only=false) {
 	global $conn;
 	$result = mysqli_query($conn, $query);
 	
 	if(true == $first_only){
 		return mysqli_fetch_assoc($result );
 	}
 	$data = array();
 	while($row = mysqli_fetch_assoc($result )){

 		$data[] = $row;
     }
 	return $data;
}