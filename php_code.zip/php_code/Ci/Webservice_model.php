<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Webservice_model extends CI_Model {
	
	public function hospitalList() 
	{		
		$this->db->select('h.*,c.name as city,s.name as sector');
		$this->db->from('hospitals as h');
		$this->db->join('cities as c','h.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','h.sector_id = s.Id','LEFT');
        $this->db->where('h.city_id', $_REQUEST['city']);  	  		
		$this->db->order_by('h.Id', 'DESC');
		$query=$this->db->get();
		if($query->num_rows()>0)
		{
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'ambulance_call'=>$res->ambulance_no,
							'emergency_call'=>$res->emergency_no,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->addess,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/hospital_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							);
			}
			return $data;
		}
		else
		{
			return False;
		}
	}
	
	public function nearBy()
	{		
		$lat=$_REQUEST['lat'];
		$lng=$_REQUEST['lng'];
		$miles= 12.4274; //set 20 km default
		$this->db->select("h.*,c.name as city,s.name as sector,( 3959 * acos( cos( radians($lat) ) * cos( radians( h.latitude ) ) * cos( radians( h.longitude ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( h.latitude ) ) ) ) AS distance");
		$this->db->from('hospitals as h');
        $this->db->join('cities as c','h.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','h.sector_id = s.Id','LEFT');		
		$this->db->having('distance <= ' . $miles);                     
		$this->db->order_by('distance');                    
		$query=$this->db->get();  
		if($query->num_rows()>0){
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'ambulance_call'=>$res->ambulance_no,
							'emergency_call'=>$res->emergency_no,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->addess,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/hospital_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							);
			}
			return $data;
		}else{
			return False;
		}
	}
	
	public function emergencyList() 
	{		
		$this->db->select('e.*,c.name as city,s.name as sector');
		$this->db->from('emergencys as e');
		$this->db->join('cities as c','e.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','e.sector_id = s.Id','LEFT');
        $this->db->where('e.city_id', $_REQUEST['city']);  	  		
		$this->db->order_by('e.Id', 'DESC');
		$query=$this->db->get();
		if($query->num_rows()>0)
		{
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'ambulance_call'=>$res->ambulance_no,
							'emergency_call'=>$res->emergency_no,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/emergency_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							);
			}
			return $data;
		}
		else
		{
			return False;
		}
	}
	
	public function nearByEmergency()
	{		
		$lat=$_REQUEST['lat'];
		$lng=$_REQUEST['lng'];
		$miles= 12.4274; //set 20 km default
		$this->db->select("e.*,c.name as city,s.name as sector,( 3959 * acos( cos( radians($lat) ) * cos( radians( e.latitude ) ) * cos( radians( e.longitude ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( e.latitude ) ) ) ) AS distance");
		$this->db->from('emergencys as e');
        $this->db->join('cities as c','e.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','e.sector_id = s.Id','LEFT');		
		$this->db->having('distance <= ' . $miles);                     
		$this->db->order_by('distance');                    
		$query=$this->db->get();  
		if($query->num_rows()>0){
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'ambulance_call'=>$res->ambulance_no,
							'emergency_call'=>$res->emergency_no,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/emergency_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							'distance'=>$res->distance
							);
			}
			return $data;
		}else{
			return False;
		}
	}
	
	public function ambulanceList() 
	{		
		$this->db->select('a.*,c.name as city,s.name as sector');
		$this->db->from('ambulances as a');
		$this->db->join('cities as c','a.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','a.sector_id = s.Id','LEFT');
        $this->db->where('a.city_id', $_REQUEST['city']);  	  		
		$this->db->order_by('a.Id', 'DESC');
		$query=$this->db->get();
		if($query->num_rows()>0)
		{
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'person_name'=>$res->person_name,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							);
			}
			return $data;
		}
		else
		{
			return False;
		}
	}
	
	public function nearByAmbulance()
	{		
		$lat=$_REQUEST['lat'];
		$lng=$_REQUEST['lng'];
		$miles= 12.4274; //set 20 km default
		$this->db->select("a.*,c.name as city,s.name as sector,( 3959 * acos( cos( radians($lat) ) * cos( radians( a.latitude ) ) * cos( radians( a.longitude ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( a.latitude ) ) ) ) AS distance");
		$this->db->from('ambulances as a');
        $this->db->join('cities as c','a.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','a.sector_id = s.Id','LEFT');		
		$this->db->having('distance <= ' . $miles);                     
		$this->db->order_by('distance');                    
		$query=$this->db->get();  
		if($query->num_rows()>0){
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'person_name'=>$res->person_name,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							'distance'=>$res->distance
							);
			}
			return $data;
		}else{
			return False;
		}
	}
	
	public function bloodBankList() 
	{		
		$this->db->select('b.*,c.name as city,s.name as sector');
		$this->db->from('blood_bank as b');
		$this->db->join('cities as c','b.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','b.sector_id = s.Id','LEFT');
        $this->db->where('b.city_id', $_REQUEST['city']);  	  		
		$this->db->order_by('b.Id', 'DESC');
		$query=$this->db->get();
		if($query->num_rows()>0)
		{
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/bank_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							);
			}
			return $data;
		}
		else
		{
			return False;
		}
	}
	
	public function nearByBloodBank()
	{		
		$lat=$_REQUEST['lat'];
		$lng=$_REQUEST['lng'];
		$miles= 12.4274; //set 20 km default
		$this->db->select("b.*,c.name as city,s.name as sector,( 3959 * acos( cos( radians($lat) ) * cos( radians( b.latitude ) ) * cos( radians( b.longitude ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( b.latitude ) ) ) ) AS distance");
		$this->db->from('blood_bank as b');
        $this->db->join('cities as c','b.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','b.sector_id = s.Id','LEFT');		
		$this->db->having('distance <= ' . $miles);                     
		$this->db->order_by('distance');                    
		$query=$this->db->get();  
		if($query->num_rows()>0){
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/bank_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							'distance'=>$res->distance
							); 
			}
			return $data;
		}else{
			return False;
		}
	}
	
	public function policeList() 
	{		
		$this->db->select('p.*,c.name as city,s.name as sector');
		$this->db->from('polices as p');
		$this->db->join('cities as c','p.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','p.sector_id = s.Id','LEFT');
        $this->db->where('p.city_id', $_REQUEST['city']);  	  		
		$this->db->order_by('p.Id', 'DESC');
		$query=$this->db->get();
		if($query->num_rows()>0)
		{
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/police_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							);
			}
			return $data;
		}
		else
		{
			return False;
		}
	}
	
	public function nearByPolice()
	{		
		$lat=$_REQUEST['lat'];
		$lng=$_REQUEST['lng'];
		$miles= 12.4274; //set 20 km default
		$this->db->select("p.*,c.name as city,s.name as sector,( 3959 * acos( cos( radians($lat) ) * cos( radians( p.latitude ) ) * cos( radians( p.longitude ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( p.latitude ) ) ) ) AS distance");
		$this->db->from('polices as p');
        $this->db->join('cities as c','p.city_id = c.Id','LEFT');
        $this->db->join('sectors as s','p.sector_id = s.Id','LEFT');		
		$this->db->having('distance <= ' . $miles);                     
		$this->db->order_by('distance');                    
		$query=$this->db->get();		
		if($query->num_rows()>0){
			foreach($query->result() as $res){
				$data[]=array('Id'=>$res->Id,
				            'name'=>$res->name,
							'email'=>$res->email,
							'contact'=>$res->contact,
							'city'=>$res->city,
							'sector'=>$res->sector,
							'address'=>$res->address,
							'latitude'=>$res->latitude,
							'longitude'=>$res->longitude,
							'description'=>strip_tags($res->description),
							'image'=>($res->image != "") ? base_url('uploads/police_img/').$res->image : '',
							'start_time'=>$res->start_time,
							'end_time'=>$res->end_time,
							'distance'=>$res->distance
							); 
			}
			return $data;
		}else{
			return False;
		}
	}
	
	public function bloodbank()
	{
		$this->db->select('*');
		$this->db->from('polices as p');
		$this->db->join('cities as c','p.city_id=c.Id','LEFT');
		$this->db->join('sectors as s','p.sector_id=s.Id','LEFT');
		$this->order_by('p.Id','DESC');
		$query=$this->db->get();
		if($query->num_rows> 0){
			foreach($query->result() as $row){
				$data=array('Id'=>$row->id,
				            'name'=>$row->name,
							'contact'=>$row->contact,
							'address'=>$row->address,
							'lat'=>$row->latitude,
							'lng'=>$row->lng,
							'desc'=>$row->description,
							'start_time'=>$row->start_time,
							'end_time'=>$row->end_time);
			}
			return $query->result();
		}else{
			return False;
		}
	}
	
	public function addFeedback()
	{
		$data=array('email'=>$_REQUEST['email'],
					'title'=>$_REQUEST['title'],
					'message'=>$_REQUEST['message'],
                    'created_at'=>date('Y-m-d H:i:s'),					
				   );			
		    $result=$this->db->insert('feedbacks',$data);
		   // $where=array('id',$_REQUEST['user_id']);  
		    //$user=$this->db->get_where('users',$where)->row_array();
		if($result)
		{ 
	    $this->load->library('email');
		$this->email->from('noreply@webmantechnologies.com', 'Hospital App');
		$this->email->to('himanshukumar.orem@gmail.com');
		$this->email->subject('New feedback submitted');
		$this->email->set_mailtype("html");	
		$this->email->message('<html><head>
		<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Perfect_Graduate</title><link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css"><style type="text/css">
			*
			{
				margin:0;
				padding:0;
			}
			body
			{
				font-family: Open Sans, sans-serif;
			}
			img
			{
				vertical-align:bottom;
			}
			a
			{
				color:#114eab;
			}
			a:hover
			{
				text-decoration:none;
			}
		</style>
	</head>
<body>
	
<div style="width:600px; background-color:#fff; border:1px solid #ccc;margin:0 auto;">
	<table style="width:100%" cellpadding="0" cellspacing="0">
		<tr>
			<td style="padding:30px;">
			
				<h3 style="font-size:18px; margin:15px 0 0 0; line-height:18px; color:#101111;">Dear Admin,</h3>
				<p style="margin:15px 0; font-size:16px; line-height:24px; color:#101111; font-weight:400;">You have got new feedback request.</p>
				<p style="margin:15px 0; font-size:16px; line-height:24px; color:#101111; font-weight:400;">
				Email: "'.$_REQUEST['email'].'" <br/>
				Title: "'.$_REQUEST['title'].'" <br/>
				Message: "'.$_REQUEST['message'].'" <br/>
				</p><br/>
				<p style="margin:15px 0; font-size:16px; line-height:24px; color:#101111; font-weight:400;">
				Kind regards, <br />
				Hospital team<br /><br />

            </td>
		</tr>
	</table>
</div>
</body>
</html>');	
//echo "<pre>"; print_r($this->email); die;		
		//$this->email->message($message);
		$this->email->send();	
		
		   return $this->db->insert_id();
		}else{
		   return False;
		}
	}
	
	public function addDevice()
	{
		$data=array('imei'=>$_REQUEST['imei'],
					'token'=>$_REQUEST['token'],
					'device_type'=>$_REQUEST['device_type'],
                    'created'=>date('Y-m-d H:i:s'),
                    'modified'=>date('Y-m-d H:i:s'),					
				   );		
		return $result=$this->db->insert('devices',$data);
	}		
	
	public function deviceList($imei=null)
	{
		$this->db->order_by('id', 'DESC');
		$this->db->where('imei', $imei);
		$query=$this->db->get('devices');		
		if($query->num_rows()>0)
		{
			//pre($query->result());die;
			return $query->row();
        }else{
		    return False;	
		}	
	}
	
	public function updateDevice($imei=null)
	{ 
		$data=array('token'=>$_REQUEST['token'],
					'device_type'=>$_REQUEST['device_type'],
                    'modified'=>date('Y-m-d H:i:s'),					
				   );	
		$this->db->where('imei', $imei);
        $this->db->update('devices', $data);
        return true; 
	}
	
	public function notificationList()
	{
		$this->db->order_by('id', 'DESC');
		$query=$this->db->get('notifications');		
		if($query->num_rows()>0)
		{
			//pre($query->result());die;
			return $query->result();
        }else{
		    return False;	
		}	
	}
}