<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webservice extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Webservice_model');      		
	}
	
	public function hospitalList()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/hospitalList?city
		if(!empty($_REQUEST['city'])){
		    $getData=$this->Webservice_model->hospitalList();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Hospital list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function nearBy()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/nearBy?lat&lng
		if(!empty($_REQUEST['lat']) && ($_REQUEST['lng'])){
		$getData=$this->Webservice_model->nearBy();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Hospital list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function emergencyList()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/emergencyList?city
		if(!empty($_REQUEST['city'])){
		    $getData=$this->Webservice_model->emergencyList();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Emergency Hospital list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function nearByEmergency()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/nearByEmergency?lat&lng
		if(!empty($_REQUEST['lat']) && ($_REQUEST['lng'])){
			$getData=$this->Webservice_model->nearByEmergency();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Emergency Hospital list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function ambulanceList()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/ambulanceList?city
		if(!empty($_REQUEST['city'])){
		    $getData=$this->Webservice_model->ambulanceList();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Ambulance list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function nearByAmbulance()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/nearByAmbulance?lat&lng
		if(!empty($_REQUEST['lat']) && ($_REQUEST['lng'])){
			$getData=$this->Webservice_model->nearByAmbulance();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Ambulance list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function bloodBankList()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/bloodBankList?city
		if(!empty($_REQUEST['city'])){
		    $getData=$this->Webservice_model->bloodBankList();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Blood bank list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function bloodbank()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/bloodbanklist?city
		if($_REQUEST['city']==''){
		   $result=$this->Webservice_model->bloodbanklist();
           if($result){
			   
		   }else{
			   $result_array=array('responce'=>1,'message'=>'Please fill all requried fields');
		   }		   
		}else{
			$result_array=array('responce'=>0,'message'=>'Please fill all requried fields');
		}
		echo json_encode($result_array);
	}
	
	public function nearByBloodBank()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/nearByBloodBank?lat&lng
		if(!empty($_REQUEST['lat']) && ($_REQUEST['lng'])){
			$getData=$this->Webservice_model->nearByBloodBank();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Blood bank list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function policeList()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/policeList?city
		if(!empty($_REQUEST['city'])){
		    $getData=$this->Webservice_model->policeList();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Police station list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
	public function nearByPolice()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/nearByPolice?lat&lng
		if(!empty($_REQUEST['lat']) && ($_REQUEST['lng'])){
			$getData=$this->Webservice_model->nearByPolice();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Police station list get succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		}else{
			$result_array = array('response'=>0,'message'=>'Please fill all requried fields!!');
		}
		echo json_encode($result_array);
		exit;
	}
	
   public function addFeedback()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/addFeedback?email&title&message  
		$result_array = array();
		if (!empty($_REQUEST['email']) && !empty($_REQUEST['title']) && !empty($_REQUEST['message']))    
		{
            $result = $this->Webservice_model->addFeedback();
				if($result){	
				   $result_array = array('response'=>1,'message' => "Your Feedback is successfully submitted!!");
				} else {
					$result_array = array('response'=>0,'message' => 'Some error occured');
				}		
		}else{
			$result_array = array('response'=>0,'message' => 'Please fill all required data');
			
		}
		echo json_encode($result_array);
	    exit();
	}
	
	public function notificationList()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/notificationList
		$getData=$this->Webservice_model->notificationList();	
			if($getData)
			{							  
				$result_array = array('response'=>1,'message'=>'Notifications listed succesfully!!','data'=>$getData);
			}
			else
			{
				$result_array = array('response'=>0,'message'=>'No data found!!');
			}
		echo json_encode($result_array);
		exit;
	}
	
	public function addDevice()
	{
		//http://webmantechnologies.com/hospital/index.php/webservice/addDevice?imei&token&device_type  
		if (!empty($_REQUEST['imei']) && !empty($_REQUEST['token']) && !empty($_REQUEST['device_type']))    
		{
			$devices = $this->Webservice_model->deviceList($_REQUEST['imei']);
			if($devices){
				$result = $this->Webservice_model->updateDevice($devices->imei);
				if($result){	
				   $result_array = array('response'=>1,'message' => "Your Device is updated successfully!!");
				} else {
					$result_array = array('response'=>0,'message' => 'Some error occured');
				}	
			    goto a;	
			}
            $result = $this->Webservice_model->addDevice();
				if($result){	
				   $result_array = array('response'=>1,'message' => "Your Device is added successfully!!");
				} else {
					$result_array = array('response'=>0,'message' => 'Some error occured');
				}		
		}else{
			$result_array = array('response'=>0,'message' => 'Please fill all required data');
			
		}
		a:
		echo json_encode($result_array);
	    exit();
	}
	
}