<?php
/*
 * Template Name: Pick Your Plan
 */
get_header();

foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_itm ) {
    $cart_key = $cart_item_key;
    $cart_item = $cart_itm;
    $_product = apply_filters( 'woocommerce_cart_item_product', $cart_itm['data'], $cart_itm, $cart_item_key );
    $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_itm['product_id'], $cart_itm, $cart_item_key );
    $product_plan = apply_filters( 'woocommerce_cart_item_plan', $cart_itm['variation']['attribute_pa_plan'], $cart_itm, $cart_item_key );
}
if( $_product && $_product->exists() ){
    $plan_variations = $_product->parent->get_available_variations();
   // echo '<pre>';
    //print_r($plan_variations ); exit;
}
?>
<section id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div id="container">
                        <div id="content" role="main">
                            <?php
                            if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_key ) ) {
                            ?>
                            <div class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_key ) ); ?>">
                                <div class="left-wrap">
                                    <div class="wrapper-img">
                                        <img src="<?php echo get_the_post_thumbnail_url(  $product_id ); ?>">
                                        <div class="icon">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/frock-2.png">
                                        </div>
                                    </div>

                                    <div class="wrapper-content">
                                        <div class="boxes-content">
                                            <h2 class="box-title"><?php echo $_product->get_title(); ?></h2>
                                            <p class="box-dec">A weekly delivery of fresh fruit, vegetables and premium proteins.
                                            <ul class="box-facility">
                                                <li>4 Meals per week</li>
                                                <li>services 2 adults</li>
                                            </ul>

                                        </div>
                                    </div>

                                </div>
                                <div class="right-wrap">
                                    <h1><?php the_title(); ?></h1>

                                    <div class="inner-title">
                                        <h4><?php echo $_product->get_title() ?></h4>
                                            
                                         <p class="price my_price"><?php echo $current_currency = get_woocommerce_currency_symbol(); 
 ?><?php echo $cart_item['data']->price; ?>.00/<?php if($product_plan == 'weekly-subscription'){?><span id="MyEdit">weekly</span><?php } else { ?><span id="MyEdit">One Off Sale</span><?php } ?></p>
                                    </div>

                                    <p class="freq">Choose your delivery frequency:</p>

                                    <div class="btn-group" >
                                            <button class="btn-sinlge <?php if($product_plan == 'one-off-sale'){ echo 'selected-plan'; } ?>" id="single" name="single" value="One off Sale">SINGLE ORDER</button>
                                            
                                            <button class="btn-week <?php if($product_plan == 'weekly-subscription'){ echo 'selected-plan'; } ?>" id="week" name="week" value="weekly">WEEKLY</button>
                                            
                                            <?php foreach($plan_variations as $plan_variation){ ?>
                                                <?php if($plan_variation['attributes']['attribute_pa_plan'] == 'one-off-sale'){ ?>
                                                    <input type="hidden" id="single_variation_id" name="single_variation_id" value="<?php echo $plan_variation['variation_id']; ?>"/> 
                                                   
                                                <?php } ?>
                                                <?php if($plan_variation['attributes']['attribute_pa_plan'] == 'weekly-subscription'){ ?>
                                                    <input type="hidden" id="weekly_variation_id" name="weekly_variation_id" value="<?php echo $plan_variation['variation_id']; ?>"/>
                                                    
                                                     
                                                <?php } ?>
                                            <?php } ?>
                                            <input type="hidden" id="cart_key"  name="cart_key" value="<?php echo $cart_key; ?>" />
                                    </div>

                                    <div class="delivery">
                                        <h4>Deliveries</h4>
                                        <ul class="del">
                                            <li>*Choose your delivery date on following page.</li>
                                            <li>*Deliveries are every Sunday and Monday.</li>
                                            <li>*Cut-off for orders is one week in advance. order must be placed by Sunday for delivery the following Sunday/Monday. </li>
                                        </ul>
                                    </div>

                                    <div class="monday-shedule">
                                        <ul class="monday">
                                            <li>MONDAY</li>
                                            <li>9am-12pm</li>
                                            <li>12pm-3pm</li>
                                            <li>3pm-6pm</li>
                                            <li>6pm-9pm</li>
                                        </ul>
                                        <ul class="moday-del">
                                            <li>DELIVERY ZONES</li>
                                            <li>WEST</li>
                                            <li>CENTRAL</li>
                                            <li>NORTH</li>
                                            <li>EAST</li>
                                        </ul>
                                    </div>

                                    <div class="sunday-shedule">
                                        <ul class="sunday">
                                            <li>SUNDAY</li>
                                            <li>9am-12pm</li>
                                            <li>12pm-3pm</li>
                                            <li>3pm-6pm</li>
                                            <li>6pm-9pm</li>
                                        </ul>
                                        <ul class="sunday-del">
                                            <li>DELIVERY ZONES</li>
                                            <li>EAST</li>
                                            <li>NORTH</li>
                                            <li>WEST</li>
                                            <li>CENTRALS</li>
                                        </ul>
                                    </div>
                                    
                                    <div class="proceed">
                                    <form action="<?php echo esc_url( WC()->cart->get_cart_url() ); ?>" method="post">
                                     <button type="submit" class="btn-pro">PROCEED</button>
                                    </form>
                                    </div>
  <?php $the_query = new WP_Query( 'page_id=4247' ); ?>

<?php while ($the_query -> have_posts()) : $the_query -> the_post();  ?>

                       <?php echo get_the_content(); ?>


     <?php endwhile;?>
                                    
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</section>
<?php
get_footer();
?>

<script type="text/javascript">
	//var change_variation_plan_ajax_fired = false;
    jQuery('#single').click(function(){
    	//if( change_variation_plan_ajax_fired == true ) return;
    	//change_variation_plan_ajax_fired = true;
        jQuery('#plan_type').val('one-off-sale');
        jQuery('#week').removeClass('selected-plan').css('cursor', 'not-allowed');
        jQuery(this).addClass('selected-plan').css('cursor', 'not-allowed');
        
        var variation_id = jQuery("#single_variation_id").val();
        var cart_key = jQuery("#cart_key").val();
        
        jQuery.ajax({
            url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
            data: {
                "action" : "change_variation_plan",
                "cart_key" : cart_key,
                "product_id" : "<?php echo $product_id; ?>",
                "variation_id" : variation_id,
                "quantity" : 1,
                "variation" : {
                    "pa_plan" : "one-off-sale"
                },
            },
            method: "POST",
            success: function(response){
                location.reload();
            }             
        });
    });
    
    
    jQuery('#week').click(function(){
    	
        jQuery('#plan_type').val('weekly-subscription');
        jQuery('#single').removeClass('selected-plan').css('cursor', 'not-allowed');
        jQuery(this).addClass('selected-plan').css('cursor', 'not-allowed');
        var text_value = jQuery('.selected-plan').val();
          
        var variation_id = jQuery("#weekly_variation_id").val();
        var cart_key = jQuery("#cart_key").val();
        
        jQuery.ajax({
            url: "<?php echo admin_url( 'admin-ajax.php' ); ?>",
            data: {
                "action" : "change_variation_plan",
                "cart_key" : cart_key,
                "product_id" : "<?php echo $product_id; ?>",
                "variation_id" : variation_id,
                "quantity" : 1,
                "variation" : {
                    "pa_plan" : "weekly-subscription"
                },
            },
            method: "POST",
            success:function(response){
                location.reload();
            }
        });
    });
</script>
