<?php
if( !function_exists( 'pr' ) ) {
    function pr( $e ) {
        echo "<pre>";
        print_r( $e );
        echo "</pre>";
    }
}
if( !function_exists( 'vd' ) ) {
    function vd( $e ) {
        echo "<pre>";
        var_dump( $e );
        echo "</pre>";
    }
}
if (!function_exists('jl')) {
    function jl( $e, $loc = __DIR__, $file_name = '', $raw_log = false ) {
        $raw_log = $raw_log === true;
        if( !is_dir( $loc ) ) $loc = __DIR__;
        if( !$file_name ) {
            $file_name = 'log' . ( !$raw_log ? '.json' : '' ) ;
        }
        $log_data = $raw_log ? print_r( $e, true ) : @json_encode( $e, JSON_PRETTY_PRINT );
        @error_log( $log_data . "\n\n", 3, $loc . "/{$file_name}" );
    }
}
if (!function_exists('lg')) {
    function lg( $e, $loc = __DIR__, $file_name = '' ) {
        jl( $e, $loc, $file_name, true );
    }
}

/**
 * Redirect users after add to cart for specific product.
 */
 
add_filter( 'auto_update_plugin', '__return_false' );
add_filter( 'auto_update_theme', '__return_false' );
 /*****************changes in mini cart**********************/



// add the filter
add_filter( 'woocommerce_cart_item_price', 'filter_woocommerce_cart_item_price', 10, 3 );


function my_custom_add_to_cart_redirect( $url ) {
    
    if ( ! isset( $_REQUEST['add-to-cart'] ) || ! is_numeric( $_REQUEST['add-to-cart'] ) ) {
		return $url;
	}
     
    $product_id = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $_REQUEST['add-to-cart'] ) );
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_itm ) {
    $cart_key = $cart_item_key;
    $cart_item = $cart_itm;
    $price = $cart_item['data']->price;
    $data = $cart_item['data'];
   }
   
   session_start();
   WC()->session->set('_my_cart_item_price', $price);
   WC()->session->set('_cart_tem_data', $data);
   
	// Only redirect the product IDs in the array to plan page
	if ( in_array( $product_id, array( 4010, 4021, 4024, 4026, 4118, 5026 ) ) ) {
        // URL to redirect to page
        $_product = wc_get_product( $product_id);
      	$url = home_url("pick-your-plan/");
      	}
    return $url;
}
add_filter( 'woocommerce_add_to_cart_redirect', 'my_custom_add_to_cart_redirect' );
/**
 * Redirect users after add to cart for specific product end.
 */

function change_variation_plan() {
    global $woocommerce;
	
    // preserver old data
    $cart = WC()->cart->get_cart();
    $old_cart_item = $cart[$_POST['cart_key']];
    $cart_item_data = array(
      'tmhasepo' => isset($old_cart_item[ 'tmhasepo' ]) ? $old_cart_item[ 'tmhasepo' ] : '',
      'tmcartepo' => isset( $old_cart_item[ 'tmcartepo' ] ) ? $old_cart_item[ 'tmcartepo' ] : ''
    );

    //remove old product from cart
    WC()->cart->remove_cart_item($_POST['cart_key']);
    ob_start();
	
    $product_id        = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $_POST['product_id'] ) );
    $quantity          = empty( $_POST['quantity'] ) ? 1 : wc_stock_amount( $_POST['quantity'] );

    $variation_id      = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : '';
    $variations         = ! empty( $_POST['variation'] ) ? (array) $_POST['variation'] : '';
   
    $passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variations, $cart_item_data );
	
	//file_put_contents(dirname(__FILE__).'/total_amt.txt', print_r($passed_validation, true));
	
    if ( $passed_validation && WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variations, $cart_item_data  ) ) {
    
		do_action( 'woocommerce_ajax_added_to_cart', $product_id);
	
		if ( get_option( 'woocommerce_cart_redirect_after_add' ) == 'yes' ) {
            
			wc_add_to_cart_message( $product_id );
        }
		
		
		// Return fragments
        WC_AJAX::get_refreshed_fragments();
    } else {
        // If there was an error adding to the cart, redirect to the product page to show any errors
        $data = array(
            'error' => true,
            'product_url' => apply_filters( 'woocommerce_cart_redirect_after_error', get_permalink( $product_id ), $product_id )
        );
        wp_send_json( $data );
    }
    die();
}

add_action( 'wp_ajax_change_variation_plan', 'change_variation_plan' );
add_action( 'wp_ajax_nopriv_change_variation_plan', 'change_variation_plan' );


/*****************************validation on add to cart. you can add only one type of product a time*****************************/

add_filter( 'woocommerce_add_cart_item_data', 'filter_woocommerce_add_cart_item_data', 10, 3 );

function filter_woocommerce_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {

	$cart_items = WC()->cart->get_cart();
	if( empty( $cart_items ) ) return $cart_item_data;
	
	$first_cart_item = current( $cart_items );
	$first_cart_item_prod_id = $first_cart_item[ 'product_id' ];
	$first_cart_item_prod = wc_get_product( $first_cart_item_prod_id );
	$first_cart_item_prod_type = $first_cart_item_prod->get_type();
	
	$product = wc_get_product( $product_id );
	 $product_type = $product->get_type();
	
	if( $first_cart_item_prod_type != $product_type ) 
	throw new Exception( sprintf( '<a href="%s" class="button wc-forward">%s</a> %s', wc_get_cart_url(), __( 'View Cart', 'woocommerce' ), 
	sprintf( __( 'Oops! A la Carte products and Food Boxes can not be purchased in the same order.  Please checkout and create a new order. 
', 'woocommerce' ), $product->get_title() ) ) );
	return $cart_item_data;
}


/******************remove checkout field from checkout page*************************/
function custom_override_checkout_fields_ek( $fields ) {
 unset($fields['billing']['billing_company']);
 return $fields;
}
add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields_ek' );


/********button text fro variab;le type product and simple type product********************/

function my_custom_cart_button_text( $text, $product ) {
    if( $product->is_type( 'variable' ) ){
        $text = __('Order Now', 'woocommerce');
    }
    elseif( $product->is_type( 'simple' ) ){
    $text = __('Add to cart', 'woocommerce');
        
    }
    return $text;
}
add_filter( 'woocommerce_product_single_add_to_cart_text', 'my_custom_cart_button_text', 10, 2 );


function action_woocommerce_ajax_added_to_cart($product_id) {
 
add_action( 'woocommerce_before_calculate_totals', 'add_custom_price' );


 }

add_action( 'woocommerce_ajax_added_to_cart', 'action_woocommerce_ajax_added_to_cart', 10, 1 ); 
    
function add_custom_price( $cart_object ) {
//file_put_contents(dirname(__FILE__).'/abc5.txt', print_r($cart_object->price , true));
    $variation_id = WC()->session->get('_variation_id');
    $item_price =  WC()->session->get('_my_cart_item_price');
    $custom_price = $item_price;  
    $target_product_id = $variation_id;
    
  
   foreach ( $cart_object->cart_contents as $value ) {
       
 // If your target product is a variation
        if ( $value['variation_id'] == $target_product_id ) {
             $value['data']->price = $custom_price;
        }
    }
  }    
//******************add to car product with customprice**********/ 
       
//function action_woocommerce_ajax_added_to_cart( $product_id ) { 

    // make action magic happen here...
//add_filter('woocommerce_get_price','donation_price', 10, 2);
//add_filter('woocommerce_get_regular_price','donation_price', 10, 2);
//add_filter('woocommerce_get_sale_price','donation_price', 10, 2);
//function donation_price($price, $productd){
//$item_price =  WC()->session->get('_my_cart_item_price');
//     if($productd->id == $product_id){
//        $price = $item_price;
//     }
//     return $price;
//}
    
     
//}; 
         
// add the action 
//add_action( 'woocommerce_ajax_added_to_cart', 'action_woocommerce_ajax_added_to_cart', 10, 1 ); 




/*******************Add Delivery Fee with every order*******************************/
//add_action( 'woocommerce_cart_calculate_fees','endo_handling_fee' );
//function endo_handling_fee() {
  //   global $woocommerce;
 
   //  if ( is_admin() && ! defined( 'DOING_AJAX' ) )
  //        return;
 
  //   $fee = 12.00;
   //  $woocommerce->cart->add_fee( 'Delivery Fee', $fee, true, 'standard' );
     
//}

/**********************Add subscription fee at check out page details**************************/

add_filter( 'woocommerce_paypal_args', 'woc_paypal_args', 100 );
function woc_paypal_args( $args ) {
    $args[ 'a3' ] = $args[ 'a1' ];
    return $args;
}

/**********************Change subscription fee during payment.*************************/

add_action( 'added_post_meta', 'woc_set_global_order_total', 10, 3 );
function woc_set_global_order_total( $meta_id, $object_id, $meta_key ) {
    if( 'shop_order' !== get_post_type( $object_id ) || '_subscriptions' !== $meta_key ) return;
    $subscription_ids = get_post_meta( $object_id, $meta_key, true );
    if( empty( $subscription_ids ) ) return;
    $subscription_id = current( $subscription_ids );
    $subscription  = ywsbs_get_subscription( $subscription_id );
    $order_ids = $subscription->order_ids;
    $order_id = current( $order_ids );
    $order = wc_get_order( $order_id );
    $order_total = $order->get_total();
    global $woc_order_total_to_set_in_new_orders;
    $woc_order_total_to_set_in_new_orders = $order_total;
}


add_action( 'updated_post_meta', 'woc_set_global_price_to_order', 10, 3 );
function woc_set_global_price_to_order( $meta_id, $object_id, $meta_key ) {
    global $woc_order_total_to_set_in_new_orders;
    if( 'order_ids' !== $meta_key || !$woc_order_total_to_set_in_new_orders ) return;
    $order_ids = get_post_meta( $object_id, $meta_key, true );
    $order_id = end( $order_ids );
    $order = wc_get_order( $order_id );
    $order->set_total($woc_order_total_to_set_in_new_orders);
    unset( $woc_order_total_to_set_in_new_orders );
}

