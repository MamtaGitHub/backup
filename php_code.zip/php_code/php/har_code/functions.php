<?php


/**
 * Proper way to enqueue scripts in admin end
 */
add_action( 'admin_enqueue_scripts', 'enqueue_my_so_scripts' );
function enqueue_my_so_scripts() {
  
  wp_enqueue_script( 'my_script', get_template_directory_uri() . '/js/my_script.js', array('jquery'));
  
}


/**
 * Proper way to create  a function for ajax request and does not response any data in success
 */
add_action('wp_ajax_pinpointBooking', 'pinpointBooking');
function pinpointBooking(){

global $wpdb;
$group_id = $_POST['group_id'];
$itme_id = $_POST['item_id'];
$results = $wpdb->get_row("SELECT * FROM wpg3_dopbsp_extras_groups_items WHERE `id` = $itme_id AND `group_id` = $group_id");

if($results){
	if($results->pinpoint_booking == 'yes'){
		$pin_req = '';
	}else{
		$pin_req = 'yes';
	}
	$wpdb->update( 'wpg3_dopbsp_extras_groups_items', array( 'pinpoint_booking' => $pin_req), array('id' => $itme_id));
}

//echo '<pre>';
//print_r($update_rec);	
}

/**
 * Proper way to enqueue scripts in frontend
 */
 add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );

function wpdocs_theme_name_scripts() {
    wp_enqueue_style( 'style-name', get_stylesheet_uri() );
    wp_enqueue_script( 'cal_date', get_template_directory_uri() . '/js/cal_date.js', array('jquery') );
}



/**
 * Proper way to add ajax function and send data in json format
 */

add_action('wp_ajax_selected_extras', 'selected_extras');
function selected_extras(){
	global $wpdb;
	$selected_item_id = $_POST['selected_item_id']; 
	$results = $wpdb->get_row("SELECT * FROM wpg3_dopbsp_extras_groups_items WHERE `id` = $selected_item_id");
	$pinpoint_booking = $results->pinpoint_booking;
	if($pinpoint_booking != ''){
		$pinpoint = $pinpoint_booking;
	}else{
		$pinpoint = 'no';
	}
	$response = array('success' => 1, 'pinpoint' => $pinpoint);
	wp_send_json($response);
}

