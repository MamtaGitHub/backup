<?php 
$PageTitle = 'Dashboard';
include_once ('top.php'); 
include("includes/fusioncharts.php");
//Search Accounts
$grab_year_search = isset($_GET['year_search']) ? $_GET['year_search'] : "";  
//Sanitize Data
$grab_year_search = sanitize_sql_string($grab_year_search);
//Check for year search if not default to current year
if($grab_year_search == '') {
$grab_year_search = $grab_year_current;
}
// $list_report_result = mysqli_query($con_db,"SELECT account_invoices.id, account_invoices.account_id, account_invoices.payment_status, account_invoice_list.account_id, account_invoice_list.list_amount FROM account_invoices INNER JOIN account_invoice_list ON account_invoices.id = account_invoice_list.account_id WHERE RIGHT(invoice_created, 4) = '$grab_year_search' ORDER BY `account_invoices`.`id` DESC");
$list_report_result = mysqli_query($con_db,"SELECT account_invoices.id, account_invoices.account_id, account_invoices.payment_status, account_invoice_list.account_id, account_invoice_list.list_amount,account_invoice_list.list_qty FROM account_invoices INNER JOIN account_invoice_list ON account_invoices.id = account_invoice_list.account_id");
//$count_accounts = mysqli_num_rows($list_report_result);
$invoice_total_cost = '0.00';
$invoice_total_cost1='0.00';
while($row = mysqli_fetch_array($list_report_result)){

$id = $row['id'];
$account_id = $row['account_id'];
$payment_status = $row['payment_status'];

$account_id = $row['account_id'];
$invoice_total_amt = $row['list_amount'];
$invoice_total_qty = $row['list_qty'];
$invoice_total_cost1= $invoice_total_amt * $invoice_total_qty;

//Check payment Stats for Paid
if($payment_status == 0) {
  
//Keep money format
//$list_amount = number_format($list_amount, 2, '.', '');         
$invoice_total_cost += preg_replace("/[^0-9\.]/", "", $invoice_total_cost1);

}
}
$show_invoice_total_cost = number_format($invoice_total_cost, 2, '.', ',');

$list_expense_cost = mysqli_query($con_db,"SELECT expense_type, sum(ex_amount) AS examount FROM `company_expenses` WHERE RIGHT(ex_date, 4) = '$grab_year_search' GROUP BY expense_type");

$count_expenses = mysqli_num_rows($list_expense_cost);
//Clear Var
$totalAmountExpenses = '0.00';
if($count_expenses != 0) {
// Print out result
while($row = mysqli_fetch_array($list_expense_cost)) {  
  //Convert Data
    $expense_name = GrabExpenseIDName($row['expense_type']);
  $expense_totalAmount = number_format($row['examount'], 2, '.', '');
  
  //Get total Expenses
  $totalAmountExpenses += $expense_totalAmount;
}
 $totalAmountExpensesConv = number_format($totalAmountExpenses, 2, '.', ',');
} 
else
{
 $totalAmountExpensesConv = '0.00';  
}
$total_profit = $invoice_total_cost - $totalAmountExpenses; 
?>
<script>
function gotoPage(select){
    window.location = select.value;
}
</script>
       <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
          <div class="row">
<?php if($rank != 5) { ?>
            <div class="col-lg-3 col-xs-6">
              <div class="small-box bg-purple-gradient">
                <div class="inner">
                  <h3><?php echo $active_accounts_count; ?></h3>
                  <p>Active Accounts</p>
                </div>
                <div class="icon">
                  <i class="fa fa-users"></i>
                </div>
                <a href="accounts.php?auth=<?php echo $salt_key_check; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>

            <div class="col-lg-3 col-xs-6">
              <div class="small-box bg-teal-gradient">
                <div class="inner">
                  <h3><?php echo $invoice_count_notpaid2; ?></h3>
                  <p>Not Paid Invoices</p>
                </div>
                <div class="icon">
                  <i class="fa fa-file-text-o"></i>
                </div>
                <a href="invoices.php?auth=<?php echo $salt_key_check; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>
      
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green-gradient">
                <div class="inner">
                  <h3>₦<?php echo $show_invoice_total_cost; ?></h3>
                  <p>Total Income without tax</p>
                </div>
                <div class="icon">
                  <i class="fa fa-line-chart"></i>
                </div>
                <a href="invoices.php?auth=<?php echo $salt_key_check; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
      
            <div class="col-lg-3 col-xs-6">
              <div class="small-box bg-red-gradient">
                <div class="inner">
                  <h3>₦<?php echo $totalAmountExpensesConv; ?></h3>
                  <p>Total Expenses</p>
                </div>
                <div class="icon">
                  <i class="fa fa-bar-chart"></i>
                </div>
                <a href="expenses.php?auth=<?php echo $salt_key_check; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
               </div>
            </div>

          </div>

     <!--performance box-->

 <div id="chart-1"></div>
 <div style="clear:both"><br/></div>

    <!--performance box end-->      
         <div class="row">
            <div class="col-md-6">
        <div class="box box-success">
                <div class="box-header with-border bg-green-gradient">
                  <h3 class="box-title">Last Accounts Created</h3>
  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus btn btn-success"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times btn btn-success"></i></button>
                  </div>        
                </div>
                <div class="box-body">
                  <ul class="products-list product-list-in-box">
<?php
$list_accounts_result = mysqli_query($con_db,"SELECT * FROM accounts WHERE added_by = '$session_login_usr' ORDER BY `accounts`.`id` DESC LIMIT 4");
$count_accounts = mysqli_num_rows($list_accounts_result);

if($count_accounts != 0) {
while($row = mysqli_fetch_array($list_accounts_result)){
$id = $row['id'];
$account_id = $row['account_id'];
$full_name = $row['full_name'];
$added_on = $row['added_on'];

$cid = mysqli_query($con_db,"SELECT * FROM accounts WHERE id = '$id' LIMIT 1");
$checkfor_cid = mysqli_num_rows($cid);
$cid = mysqli_fetch_assoc($cid);

if($cid['company'] == '') { 
$company_name = '';
} else {
$company_name = '- '.$cid['company']; 
}
?>  
            <li class="item">
            <div class="product-img">
              <img src="dist/img/accounts.png" alt="Accounts ID">
            </div>
            <div class="product-info">
            <a href="view_account.php?auth=<?php echo $salt_key_check; ?>&cid=<?php echo $id; ?>" class="product-title">Account ID <?php echo $account_id; ?> <?php echo $company_name; ?> <span class="pull-right"><?php echo $added_on; ?></span></a>
            <span class="product-description">
               <?php echo $full_name; ?>
            </span>
             </div>
             </li>
<?php } } else { ?>   
<li class="item"><strong>No Recent Accounts Added.</strong></li>
<?php } ?>                            
                  </ul>
                </div>
                <div class="box-footer text-center">
                  <a href="accounts.php?auth=<?php echo $salt_key_check; ?>" class="uppercase">View All Accounts</a>
                </div>
              </div>
        </div>        
        
      
       <div class="col-md-6">
        <div class="box box-success">
                <div class="box-header with-border bg-green-gradient">
                  <h3 class="box-title">Account Reminders</h3>
<div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus btn btn-success"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times btn btn-success"></i></button>
                  </div>          
                </div>
                <div class="box-body">
                  <ul class="products-list product-list-in-box">
                  <?php
$list_accounts_result = mysqli_query($con_db,"SELECT * FROM account_history WHERE follow_up = '1' and added_by = '$session_login_usr' ORDER BY `account_history`.`id` DESC LIMIT 4");
$count_accounts = mysqli_num_rows($list_accounts_result);

if($count_accounts != 0) {
while($row = mysqli_fetch_array($list_accounts_result)){
$id_acc = $row['id'];
$account_id = $row['account_id'];
$comments = $row['comments'];
$follow_up = $row['follow_up'];
$added_on = $row['added_on'];


$list_accountid_result = mysqli_query($con_db,"SELECT * FROM accounts WHERE account_id = '$account_id' LIMIT 1");
while($row4 = mysqli_fetch_array($list_accountid_result)){
$getid_account = $row4['id'];
$getcompany = $row4['company'];

if($getcompany == '') { 
$company_name_4 = '';
} else {
$company_name_4 = '- '.$row4['company'];  
} }
?>  
            <li class="item">
            <div class="product-img">
                        <img src="dist/img/account_alert.png" alt="Accounts ID">
                      </div>
            <div class="product-info">
            <a href="account_history.php?auth=<?php echo $salt_key_check; ?>&cid=<?php echo $getid_account; ?>" class="product-title">Account ID <?php echo $account_id; ?> <?php echo $company_name_4; ?><span class="pull-right"><?php echo $added_on; ?></span></a>
                        <span class="product-description">
                          <?php echo base64_decode($comments); ?>
                        </span>
                      </div></li>
<?php } } else { ?>   
<li class="item"><strong>No Accounts Reminders.</strong></li>
<?php } ?>
                  </ul>
                </div>
                <div class="box-footer text-center">
                  <a href="report_reminders.php?auth=<?php echo $salt_key_check; ?>" class="uppercase">View All Reminders</a>
                </div>
              </div>
      </div>
    <?php

 
  $result = mysqli_query($con_db,"SELECT * FROM invoice_type");

    
 

 $arrData = array(
      "chart" => array(
          "caption" => "PERFORMANCE OF KASUPDA office.",
          "paletteColors" => "#0075c2",
          "bgColor" => "#ffffff",
          "borderAlpha"=> "20",
          "canvasBorderAlpha"=> "0",
          "usePlotGradientColor"=> "0",
          "plotBorderAlpha"=> "10",
          "showXAxisLine"=> "1",
          "xAxisLineColor" => "#999999",
          "showValues" => "0",
          "divlineColor" => "#999999",
          "divLineIsDashed" => "1",
          "showAlternateHGridColor" => "0"
        )
    );

    $arrData["data"] = array();
  


    // Push the data into the array
    $i = 0;
    //$arrData = array();
    $total_amt = '';

    while($row = mysqli_fetch_assoc($result)) {
  // echo "<pre>";
  // print_r($row);
    $result1 = mysqli_query($con_db,"SELECT sum(ail.list_amount)  as totalAmt FROM account_invoices as ai left join account_invoice_list as ail on ai.id=ail.account_id WHERE ai.invoice_type='".$row['id']."' GROUP BY ai.invoice_type");
    // echo "SELECT sum(ail.list_amount)  as totalAmt FROM account_invoices as ai left  join account_invoice_list as ail on ai.id=ail.account_id WHERE ai.invoice_type='".$row['id']."' GROUP BY ai.invoice_type<br/>";

     $row1 = mysqli_fetch_assoc($result1);
      
     // $result2 = mysqli_query($con_db,"SELECT list_amount FROM account_invoice_list WHERE account_id=".$row1['id']);
    //  while($row2 = mysqli_fetch_assoc($result2)) {
       //  echo "<pre>";
       // print_r($row1); 
  //      $list_account += $row2['list_amount'];
  // echo $list_account;
       $total_amt = $row1['totalAmt'];
      // $name = $row['invoice_type'];
     //  echo $total_amt;
  
      
   //   }

   

     array_push($arrData["data"], array(
      "label" =>$row['type_name'],
      "value" =>$total_amt
      )
    );

      
  }
  // echo '<pre>';
  // print_r($arrData);
  // exit;
    /*JSON Encode the data to retrieve the string containing the JSON representation of the data in the array. */

    $jsonEncodedData = json_encode($arrData);
    //print_r($jsonEncodedData); exit;

    /*Create an object for the column chart using the FusionCharts PHP class constructor. Syntax for the constructor is ` FusionCharts("type of chart", "unique chart id", width of the chart, height of the chart, "div id to render the chart", "data format", "data source")`. Because we are using JSON data to render the chart, the data format will be `json`. The variable `$jsonEncodeData` holds all the JSON data for the chart, and will be passed as the value for the data source parameter of the constructor.*/

    $columnChart = new FusionCharts("column2D", "myFirstChart" , 1000, 300, "chart-1", "json", $jsonEncodedData);

    // Render the chart
    $columnChart->render();

    
  

?>
        <div id="chart-1"></div>
       
        </section>
      </div>
   <script>
  $(function () {
    //--------------
    //- AREA CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var areaChartCanvas = $("#areaChart").get(0).getContext("2d");
    // This will get the first returned node in the jQuery collection.
    var areaChart = new Chart(areaChartCanvas);

    var areaChartData = {
      labels: ["January", "February", "March", "April", "May", "June", "July", "August","September", "October", "November" ,"December"],
      datasets: [
        {
          label: "Invoice Amount",
          fillColor: "rgba(2,167,91,0.9)",
          strokeColor: "rgba(1,117,64,0.8)",
          pointColor: "#008d4c",
          pointStrokeColor: "rgba(1,117,64,1)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(1,117,64,1)",
<?php
$list_report_result = mysqli_query($con_db,"
       SELECT ai.id, ai.account_id, ai.payment_status, ail.account_id, ail.list_amount, 
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 01 THEN ail.list_amount ELSE 0 END) AS Jan,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 02 THEN ail.list_amount ELSE 0 END) AS Feb,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 03 THEN ail.list_amount ELSE 0 END) AS Mar,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 04 THEN ail.list_amount ELSE 0 END) AS Apr,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 05 THEN ail.list_amount ELSE 0 END) AS May,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 06 THEN ail.list_amount ELSE 0 END) AS Jun,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 07 THEN ail.list_amount ELSE 0 END) AS Jul,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 08 THEN ail.list_amount ELSE 0 END) AS Aug,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 09 THEN ail.list_amount ELSE 0 END) AS Sep,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 10 THEN ail.list_amount ELSE 0 END) AS 'Oct',
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 11 THEN ail.list_amount ELSE 0 END) AS Nov,
       SUM(CASE WHEN LEFT(ai.invoice_created, 2) = 12 THEN ail.list_amount ELSE 0 END) AS 'Dec',
       SUM(ail.list_amount) AS Total
FROM account_invoices ai 
LEFT JOIN account_invoice_list ail ON (ai.id=ail.account_id)
WHERE ai.payment_status = '0' AND RIGHT(ai.invoice_created, 4) = '$grab_year_search'");
;



$count_accounts = mysqli_num_rows($list_report_result);

if($count_accounts != 0) {
while($row = mysqli_fetch_array($list_report_result)){

$Get_Jan = number_format($row['Jan'], 2, '.', '');
$Get_Feb = number_format($row['Feb'], 2, '.', '');
$Get_Mar = number_format($row['Mar'], 2, '.', '');
$Get_Apr = number_format($row['Apr'], 2, '.', '');
$Get_May = number_format($row['May'], 2, '.', '');
$Get_Jun = number_format($row['Jun'], 2, '.', '');
$Get_Jul = number_format($row['Jul'], 2, '.', '');
$Get_Aug = number_format($row['Aug'], 2, '.', '');
$Get_Sep = number_format($row['Sep'], 2, '.', '');
$Get_Oct = number_format($row['Oct'], 2, '.', '');
$Get_Nov = number_format($row['Nov'], 2, '.', '');
$Get_Dec = number_format($row['Dec'], 2, '.', '');

}

echo 'data: ['.$Get_Jan.','.$Get_Feb.','.$Get_Mar.','.$Get_Apr.','.$Get_May.','.$Get_Jun.','.$Get_Jul.','.$Get_Aug.','.$Get_Sep.','.$Get_Oct.','.$Get_Nov.','.$Get_Dec.',]';

} else {
echo 'data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]';  
} 
?>     
        },

        {
          label: "Expenses",
          fillColor: "rgba(222, 75, 75, 1)",
          strokeColor: "rgba(160, 5, 5, 1)",
          pointColor: "rgba(160, 5, 5, 1)",
          pointStrokeColor: "#de4b4b",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(222,75,75,1)",
<?php     
$list_report_result = mysqli_query($con_db,"
SELECT id, ex_date, ex_amount,
       SUM(CASE WHEN LEFT(ex_date, 2) = 01 THEN ex_amount ELSE 0 END) AS Jan,
       SUM(CASE WHEN LEFT(ex_date, 2) = 02 THEN ex_amount ELSE 0 END) AS Feb,
       SUM(CASE WHEN LEFT(ex_date, 2) = 03 THEN ex_amount ELSE 0 END) AS Mar,
       SUM(CASE WHEN LEFT(ex_date, 2) = 04 THEN ex_amount ELSE 0 END) AS Apr,
       SUM(CASE WHEN LEFT(ex_date, 2) = 05 THEN ex_amount ELSE 0 END) AS May,
       SUM(CASE WHEN LEFT(ex_date, 2) = 06 THEN ex_amount ELSE 0 END) AS Jun,
       SUM(CASE WHEN LEFT(ex_date, 2) = 07 THEN ex_amount ELSE 0 END) AS Jul,
       SUM(CASE WHEN LEFT(ex_date, 2) = 08 THEN ex_amount ELSE 0 END) AS Aug,
       SUM(CASE WHEN LEFT(ex_date, 2) = 09 THEN ex_amount ELSE 0 END) AS Sep,
       SUM(CASE WHEN LEFT(ex_date, 2) = 10 THEN ex_amount ELSE 0 END) AS 'Oct',
       SUM(CASE WHEN LEFT(ex_date, 2) = 11 THEN ex_amount ELSE 0 END) AS Nov,
       SUM(CASE WHEN LEFT(ex_date, 2) = 12 THEN ex_amount ELSE 0 END) AS 'Dec',
       SUM(ex_amount) AS Total FROM company_expenses WHERE RIGHT(ex_date, 4) = '$grab_year_search'");
;

$count_accounts = mysqli_num_rows($list_report_result);

if($count_accounts != 0) {
while($row = mysqli_fetch_array($list_report_result)){

$Get_Jan = number_format($row['Jan'], 2, '.', '');
$Get_Feb = number_format($row['Feb'], 2, '.', '');
$Get_Mar = number_format($row['Mar'], 2, '.', '');
$Get_Apr = number_format($row['Apr'], 2, '.', '');
$Get_May = number_format($row['May'], 2, '.', '');
$Get_Jun = number_format($row['Jun'], 2, '.', '');
$Get_Jul = number_format($row['Jul'], 2, '.', '');
$Get_Aug = number_format($row['Aug'], 2, '.', '');
$Get_Sep = number_format($row['Sep'], 2, '.', '');
$Get_Oct = number_format($row['Oct'], 2, '.', '');
$Get_Nov = number_format($row['Nov'], 2, '.', '');
$Get_Dec = number_format($row['Dec'], 2, '.', '');

}

echo 'data: ['.$Get_Jan.','.$Get_Feb.','.$Get_Mar.','.$Get_Apr.','.$Get_May.','.$Get_Jun.','.$Get_Jul.','.$Get_Aug.','.$Get_Sep.','.$Get_Oct.','.$Get_Nov.','.$Get_Dec.',]';

} else {
echo 'data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]';  
} 
?>  
        }   
    
      ]
    };

    var areaChartOptions = {
      //Boolean - If we should show the scale at all
      showScale: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: true,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0,0,0,.05)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - Whether the line is curved between points
      bezierCurve: true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension: 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot: true,
      //Number - Radius of each point dot in pixels
      pointDotRadius: 4,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth: 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius: 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke: true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth: 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill: true,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].lineColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio: true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive: true
    };

    //Create the line chart
    areaChart.Line(areaChartData, areaChartOptions);

   
    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
    var pieChart = new Chart(pieChartCanvas);
    var PieData = [ 
<?php
$list_expense_cost = mysqli_query($con_db,"SELECT expense_type, sum(ex_amount) AS examount FROM `company_expenses` WHERE RIGHT(ex_date, 4) = '$grab_year_search' GROUP BY expense_type");
$count_expenses = mysqli_num_rows($list_report_result);
//Clear Var
$totalAmountExpenses = '0.00';
if($count_expenses != 0 or $count_expenses == 1) {

$color_array = array('#00a65a','#f39c12','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#39cccc','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#00a65a','#f39c12','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954','#a612f3','#f39c12','#00a65a','#00c0ef','#3c8dbc','#d2d6de','#f56954');
$x=0;

//Print out result
while($row = mysqli_fetch_array($list_expense_cost)) {  
  //Convert Data
    $expense_name = GrabExpenseIDName($row['expense_type']);
  $expense_totalAmount = number_format($row['examount'], 2, '.', '');
  
  $class = $color_array[$x];
  $x++;
  
echo "{
        value: '$expense_totalAmount',
        color: '$class',
        highlight: '$class',
        label: '$expense_name'
      },";  

} } else {
        echo '
    {
        value: "100",
        color: "#d2d6de",
        highlight: "#d2d6de",
        label: "No Data Found"
      }';
  
}
?>  
    ];
    var pieOptions = {
      //Boolean - Whether we should show a stroke on each segment
      segmentShowStroke: true,
      //String - The colour of each segment stroke
      segmentStrokeColor: "#fff",
      //Number - The width of each segment stroke
      segmentStrokeWidth: 2,
      //Number - The percentage of the chart that we cut out of the middle
      percentageInnerCutout: 50, // This is 0 for Pie charts
      //Number - Amount of animation steps
      animationSteps: 80,
      //String - Animation easing effect
      animationEasing: "easeOutBounce",
      //Boolean - Whether we animate the rotation of the Doughnut
      animateRotate: true,
      //Boolean - Whether we animate scaling the Doughnut from the centre
      animateScale: false,
      //Boolean - whether to make the chart responsive to window resizing
      responsive: true,
      // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio: true,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
    };
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    pieChart.Doughnut(PieData, pieOptions);
  });
</script>
<?php } else { ?>
<script type='text/javascript' language='javascript'> 
//View PDF Function
function viewReport(id){
    windowObjectReference = window.open(
    "view_PDFinvoice.php?cid="+ id +"&action=allow_usr&decode=<?php echo $salt_key_hash; ?>&cp=<?php echo base64_encode($account_perm); ?>&dl=0",
    "DescriptiveWindowName",
    "width=850,height=800,resizable,scrollbars,status"
  );
  } 
</script>
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
      <div class="row">
            <div class="col-xs-3">All Invoices</div>
      <div class="col-xs-5">
      </div></div>
          </form>
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box box-primary">
                <div class="box-body">
                  <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
            <th>Controls</th>
            <th>Company/Name</th>
                        <th>Invoice Type</th>
                        <th>Created On</th>
                        <th>Due</th>
            <th>Created By</th>
            <th>Type</th>
            <th>Amount Due</th>
            <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
<?php 
$list_accounts_result = mysqli_query($con_db,"SELECT * FROM account_invoices WHERE account_id = '$account_perm' ORDER BY `account_invoices`.`id` DESC");
$count_accounts = mysqli_num_rows($list_accounts_result);

if($count_accounts != 0) {
while($row = mysqli_fetch_array($list_accounts_result)){

$id = $row['id'];
$account_id = $row['account_id'];
$invoice_type = $row['invoice_type'];
$invoice_created = $row['invoice_created'];
$invoice_due = $row['invoice_due'];
$created_by = $row['created_by'];
$payment_type = $row['payment_type'];
$payment_status = $row['payment_status'];


if($payment_status == '0') {
$payment_status = '<span class="label label-success">Paid</span>'; 
} else if($payment_status == '1'){
$payment_status = '<span class="label label-warning">Pending</span>';
} else if($payment_status == '2'){
$payment_status = '<span class="label label-danger">Canceled</span>';
} else if($payment_status == '3'){
$payment_status = '<span class="label label-danger">Not Paid</span>';
} else if($payment_status == '4'){
$payment_status = '<span class="label label-info">Unknown</span>';
} else {
$payment_status = '<span class="label label-info">Unknown</span>';  
}

//Get AccountName
$newaccount_id = GrabAccountIDName($account_id);
$invoice_company = GrabAccountIDCompanyName($account_id);
$newinvoice_type = GrabTypeIDName($invoice_type);
$newpayment_status = GrabPaymentIDName($payment_type);

//Encode Data for Paypal
$id_encode = base64_encode($id);
$invoice_type_encode = base64_encode($invoice_type);

//Get invoice total Amount
$sub_pay = '';
$list_accountsDetails_result = mysqli_query($con_db,"SELECT * FROM account_invoice_list WHERE account_id = '$id' and list_amount != ''");
$invoice_details = mysqli_num_rows($list_accountsDetails_result);
if($invoice_details != '') {
while($row = mysqli_fetch_array($list_accountsDetails_result)){

$list_amount = $row['list_amount'];

$sub_pay += $list_amount;
}
//Keep money format
$sub_pay = number_format($sub_pay, 2, '.', '');
//Add Sales Tax
$add_withtax = number_format($tax_percent * $sub_pay, 2, '.', '');
 //Total with Sales Tax
$total_withtax_added = number_format($add_withtax + $sub_pay, 2, '.', ',');
} else {
  $total_withtax_added = '0.00';
}
//Set Perm
$checPERM = "&cp=".base64_encode($account_perm);
          
        echo "<tr>
            <td>
              <a href='#' onClick='viewReport(".$id.")' role='button' title='View PDF Invoice' class='btn btn-primary btn-md'><i class='fa fa-file-pdf-o'></i></a>
              <a href='view_PDFinvoice.php?auth=$salt_key_check&cid=$id&action=allow_usr&decode=$salt_key_hash&$checPERM&dl=1' role='button' title='Download PDF Invoice' class='btn bg-purple btn-md'><i class='fa fa-download'></i></a>
              <a href='make_payment.php?auth=$salt_key_check&cid=$id_encode&pid=$invoice_type_encode' target='_blank' role='button' title='Pay using Paypal' class='btn btn-info btn-md'><i class='fa fa-paypal'></i></a>   
                        </td>
            <td>$invoice_company - $newaccount_id</td>
            <td>$newinvoice_type</td>
                        <td>$invoice_created</td>
                        <td>$invoice_due</td>
                        <td>$created_by</td>
            <td>$newpayment_status</td>
            <td>$$total_withtax_added</td>
            <td>$payment_status</td>
                      </tr>";
} 
}
?>            
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
</div>
</section>
</div>
<?php } ?>
<?php include_once ('bottom.php'); ?>
